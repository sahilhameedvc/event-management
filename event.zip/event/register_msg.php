<div class="container-fluid">
	<p>We will contact you soon for the verification of your registration request. Thank you</p>
</div>
<div class="modal-footer display">
	<div class="row">
		<div class="col-md-12">
			<button class="btn btn-secondary float-right" type="button" data-dismiss="modal">Close</button>
		</div>
	</div>
</div>
<style>
	#uni_modal .modal-footer{
		display: none;
	}
	#uni_modal .modal-footer.display{
		display: block;
	}
</style>